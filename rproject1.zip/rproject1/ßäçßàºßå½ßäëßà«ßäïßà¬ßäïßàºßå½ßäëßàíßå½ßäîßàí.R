a <- 10
b <- 20
print(a + b)

c <- a + b

cat('더한 결과 값은 : ', a + b)
cat('더한 결과 값은 : ', c, '입니다.')
