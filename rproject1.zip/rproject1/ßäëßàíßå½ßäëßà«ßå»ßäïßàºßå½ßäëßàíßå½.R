## 변수에 2개의 넣고,
## 1. 사칙연산과
## 2. 더한 결과값의 절대값(abs())과
## 더한 결과값의 루트값(sqrt())을 
## 구해서 실행해보세요.
## 3. 나머지(%%)를 구해보세요.
## 파일이름은 산술연산.R

## packages탭 사용 
## packages 설치: ggplot2

## 명령어 사용
## packages 설치 : cowsay 
install.packages("cowsay")
