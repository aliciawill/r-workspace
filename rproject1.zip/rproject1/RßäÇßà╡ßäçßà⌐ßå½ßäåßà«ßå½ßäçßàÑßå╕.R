print('안녕하세요.')

a <- 100 #할당연산자 
b <- 200

print(a * b)

c <- 500 ##alt + -

# ctrl + /: 주석
# ctlr + L: clear console

install.packages("glue")

d <- 1:10 #연속적인 값 
print(d)

e <- c(1, 3, 7, 8)
e

f <- c(1, 3:5, 8:10)
f



